package io.nitro.antlers.views.login;

public class LoginView {
    
}
