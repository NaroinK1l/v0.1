@NullMarked
package io.nitro.antlers.security.domain;

import org.jspecify.annotations.NullMarked;
