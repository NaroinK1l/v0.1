/**
 * This package contains reusable domain classes.
 */
@NullMarked
package io.nitro.antlers.base.domain;

import org.jspecify.annotations.NullMarked;
