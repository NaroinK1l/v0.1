package io.nitro.antlers.security;

import com.vaadin.flow.spring.security.VaadinWebSecurity;
import io.nitro.antlers.views.login.LoginView;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

@Configuration
public class SecurityConfiguration extends VaadinWebSecurity {

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        // 1) Разрешаем публичные ресурсы (Ant-паттерны)
        RequestMatcher[] publicMatchers = new RequestMatcher[] {
            AntPathRequestMatcher.antMatcher("/login"),
            AntPathRequestMatcher.antMatcher("/create.html"),
            AntPathRequestMatcher.antMatcher("/firebase-app.js"),

            // статика
            AntPathRequestMatcher.antMatcher("/favicon.ico"),
            AntPathRequestMatcher.antMatcher("/icons/**"),
            AntPathRequestMatcher.antMatcher("/images/**"),
            AntPathRequestMatcher.antMatcher("/manifest.webmanifest"),
            AntPathRequestMatcher.antMatcher("/sw.js"),
            AntPathRequestMatcher.antMatcher("/offline.html"),
            AntPathRequestMatcher.antMatcher("/frontend/**"),
            AntPathRequestMatcher.antMatcher("/webjars/**"),
            AntPathRequestMatcher.antMatcher("/VAADIN/**"),
            AntPathRequestMatcher.antMatcher("/vaadin/**"),
            AntPathRequestMatcher.antMatcher("/error"),
            AntPathRequestMatcher.antMatcher("/**/*.js"),
            AntPathRequestMatcher.antMatcher("/**/*.css"),
            AntPathRequestMatcher.antMatcher("/**/*.html")
        };

        http.authorizeHttpRequests(auth -> auth
            .requestMatchers(publicMatchers).permitAll()
        );

        // 2) Базовая настройка Vaadin (добавит anyRequest().authenticated())
        super.configure(http);

        // 3) Указываем страницу логина
        setLoginView(http, io.nitro.antlers.views.login.LoginView.class);
    }
}

